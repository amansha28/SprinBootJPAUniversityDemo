package com.example.universitydemo.model;


import javax.persistence.*;
import java.util.List;

@Entity
@IdClass(ScheduleId.class)
public class Schedule {

//    @Id
//    @JoinColumn(name="professor_id",referencedColumnName = "id")
//    private int professor_id;

//    @Id
//    @JoinColumn(name="course_id", referencedColumnName = "id")
//    private int course_id;


    @Id
    @ManyToOne()
//    @JoinColumn(name="professor_id",referencedColumnName = "id")
    private Professor professor;


    @Id
    @ManyToOne()
    private Course course;

    @Id
    private int semester;
    @Id
    @Column(name="`YEAR`")
    private int year;

}
