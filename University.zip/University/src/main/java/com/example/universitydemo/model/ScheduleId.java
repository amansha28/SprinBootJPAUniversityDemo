package com.example.universitydemo.model;

import java.io.Serializable;
import java.util.Objects;

public class ScheduleId implements Serializable {

    private int professor;

    private int course;
    private int semester;
    private int year;

    public ScheduleId() {
    }

    public ScheduleId(int professor, int course, int semester, int year) {
        this.professor = professor;
        this.course = course;
        this.semester = semester;
        this.year = year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ScheduleId that = (ScheduleId) o;
        return professor == that.professor && course == that.course && semester == that.semester && year == that.year;
    }

    @Override
    public int hashCode() {
        return Objects.hash(professor, course, semester, year);
    }
}
