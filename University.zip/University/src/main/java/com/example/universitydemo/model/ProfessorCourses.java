package com.example.universitydemo.model;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ProfessorCourses {

    private int name;
    private List<Course> courses;

    public ProfessorCourses() {
    }

    public ProfessorCourses(int name, List<Course> courses) {
        this.name = name;
        this.courses = courses;
    }

    public int getName() {
        return name;
    }

    public void setName(int name) {
        this.name = name;
    }

    public List<Course> getCourses() {
        return courses;
    }

    public void setCourses(List<Course> courses) {
        this.courses = courses;
    }

    @Override
    public String toString() {
        return "ProfessorCourses{" +
                "name=" + name +
                ", courses=" + courses +
                '}';
    }
}
