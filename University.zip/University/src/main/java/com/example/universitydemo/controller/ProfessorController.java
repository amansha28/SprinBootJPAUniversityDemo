package com.example.universitydemo.controller;


import com.example.universitydemo.dao.ProfessorDao;
import com.example.universitydemo.dao.ScheduleDao;
import com.example.universitydemo.model.Professor;
import com.example.universitydemo.model.ProfessorCourses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProfessorController {

    @Autowired
    ProfessorDao professorDao;

    @Autowired
    ScheduleDao scheduleDao;

    @GetMapping("/professors")
    public List<Professor> getAllProfessor(){
        return professorDao.findAll();
    }

    @GetMapping("/search")
    public List<ProfessorCourses> getAllProfessorCourses(){
        List<ProfessorCourses> list =  scheduleDao.getAllProfessorCourses();
        System.out.println("Size : "+list.size());
        return list;
    }

}
